/**
 * require artDialog 5.0.4.
 *
 * @author Baishui2004
 * @Date March 21, 2014
 */
(function ($) {

    $.bsgrid_artDialog = {
        okValue: 'OK',
        cancelValue: 'Cancel',
        alertDialogTitle: 'Message',
        confirmDialogTitle: 'Confirm',
        promptDialogTitle: 'Prompt'
    };

})(jQuery);