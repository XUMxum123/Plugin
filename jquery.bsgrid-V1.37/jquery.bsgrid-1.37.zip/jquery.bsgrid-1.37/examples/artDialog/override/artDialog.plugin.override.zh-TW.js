/**
 * require artDialog 5.0.4.
 *
 * @author Baishui2004
 * @Date March 21, 2014
 */
(function ($) {

    $.bsgrid_artDialog = {
        okValue: '確定',
        cancelValue: '取消',
        alertDialogTitle: '提示',
        confirmDialogTitle: '確認',
        promptDialogTitle: '輸入'
    };

})(jQuery);